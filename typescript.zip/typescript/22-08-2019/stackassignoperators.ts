var pref= {
    "+" : 1,
    "-" : 1,
    "*" : 2,
    "/" : 2,
    "^" : 3
 }
 //console.log(pref["*"]);
let numarray:number[]=[];
let strarray:string[]=[];
let expr:string="3*2+123-10";
let value:number=0;
for(let i=0;i<expr.length;i++){
    if(expr[i]=='+' || expr[i]=='-' || expr[i]=='*' || expr[i]=='/' ) {
        if(strarray.length==0)
            strarray.push(expr[i]);
        else if(pref[strarray[strarray.length-1]] <= pref[expr[i]])
             strarray.push(expr[i]);
        else if(pref[strarray[strarray.length-1]] > pref[expr[i]]){
            while(strarray.length>0 && pref[strarray[strarray.length-1]] >= pref[expr[i]]){
            let a=numarray.pop();
            let b=numarray.pop();
            let oper=strarray.pop();
            numarray.push(switoper(a,b,oper));
          }
          strarray.push(expr[i]);
        }
        else{
            while(strarray.length>0){
                let a=numarray.pop();
                let b=numarray.pop();
                let oper=strarray.pop();
                
            numarray.push(switoper(a,b,oper));
            }
        }
    }
    else {
        let stri:string="";
        let k=i;
        while(k<expr.length && expr[k]!='+' && expr[k]!='-' && expr[k]!='*' && expr[k]!='/') {
            stri+=expr[k];k++;
        }
        let x:number=parseInt(stri);
        numarray.push(x);
        if(stri.length>1)
            i+=stri.length-1;
    }
}
if(strarray.length!=0){
    while(strarray.length>0){
        let a=numarray.pop();
        let b=numarray.pop();
        let oper=strarray.pop();
        
        numarray.push(switoper(a,b,oper));
    }
}
function switoper(a:number,b:number,oper:string):number{
    let x:number=0;
    switch(oper){
        case "*":{x=a*b;break;}
        case "/":{x=b/a;break;}
        case "+":{x=a+b;break;}
        case "-":{x=b-a;break;}
    }
    return x;
}
console.log(numarray);