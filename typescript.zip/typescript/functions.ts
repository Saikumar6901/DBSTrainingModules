//ts = js+extras

//functions with diff params

function usingParams(pRequired:boolean, pDefault:String="DBS-IND",
 pOptional?:number,  ...pRestParams:String[]): void{
    console.log(pRequired+" "+pDefault+" "+pOptional+" rest "+pRestParams);
}
console.log(usingParams(true));
console.log(usingParams(true,"saikumar"));
console.log(usingParams(true,'123'));
console.log(usingParams(true,"saikumar",123));
console.log(usingParams(true,"saikumar",12,"pragada","abhinav","bhargav","bhargav","bhargav","bhargav"));

//function which returns a function
function returnFuntions(): any{
return (a:String):String => {return a;} ;
}
//console.log("Hello "+ returnFuntions()("Saikumar ") + "Rao"); //urrying of functions

// self invokable function

//(<function implementation>)();
// Eg: (function(){})();

(function(){
    console.log("first");
    return (a:String):String => {
        console.log("second");return a;
        } ;
    })()("saikumar");

var selffun=(function(){
    console.log("self function");
})();

//lambda or arrow functions
console.log("lambda ********* :):):)");

(() => {
    console.log("first");
    return (a:String) => {
        console.log("second");return a;
        };
    })()("saikumar");

console.log((() => "hi saku")());

var out =(a)=>(x,y)=>x+y+a;
console.log(out(10)(20,30));

var out1 = function(a: number){
              return function(x: number , y: number){
                    return a+x+y;
                }
            };
console.log("Hi "+out1(1)(2,3));


let arr123:number[]=[45, 40, 32, 12, 67, 88, 45, 24, 19];
console.log(arr123.filter((e:number) => e % 4 == 0));