var abc=10;
if(abc==10){
    var bd=100;
    let abc=20;
    console.log(abc);
}
console.log(abc);
console.log(bd);