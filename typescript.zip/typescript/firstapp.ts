//ts=js

function class12(){
    this.propertyName="a js property"
    this.fun=function(){console.log("js functiuon");}
}
var obj=new class12();
console.log(obj);
console.log(obj.propertyName);
console.log(obj.fun());

let name1 = "saikumar";
name1 = 4+"";
console.log(name1);

var name123:string = 'saikumar';
var arr:string[]=["mobile","pc"];
var objapp:any = {key:'value'};
console.log(objapp);
console.log(arr);

//functions
function fun():String{
    return "hi there i'm saikumar";
}
console.log(fun());

let booll = false;
let xyz = booll?10:5;
console.log(xyz);

var fundoo = function(): String {
    return "in fundoo";
}
console.log(fundoo());

