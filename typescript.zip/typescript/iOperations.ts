export  interface iOperations {
    getName():string;
    getAge():number;
}