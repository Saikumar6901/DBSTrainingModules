//ts = js+extras
//functions with diff params
function usingParams(pRequired, pDefault, pOptional) {
    if (pDefault === void 0) { pDefault = "DBS-IND"; }
    var pRestParams = [];
    for (var _i = 3; _i < arguments.length; _i++) {
        pRestParams[_i - 3] = arguments[_i];
    }
    console.log(pRequired + " " + pDefault + " " + pOptional + " rest " + pRestParams);
}
console.log(usingParams(true));
console.log(usingParams(true, "saikumar"));
console.log(usingParams(true, '123'));
console.log(usingParams(true, "saikumar", 123));
console.log(usingParams(true, "saikumar", 12, "pragada", "abhinav", "bhargav", "bhargav", "bhargav", "bhargav"));
//function which returns a function
function returnFuntions() {
    return function (a) { return a; };
}
//console.log("Hello "+ returnFuntions()("Saikumar ") + "Rao"); //urrying of functions
// self invokable function
//(<function implementation>)();
// Eg: (function(){})();
(function () {
    console.log("first");
    return function (a) {
        console.log("second");
        return a;
    };
})()("saikumar");
var selffun = (function () {
    console.log("self function");
})();
//lambda or arrow functions
console.log("lambda ********* :):):)");
(function () {
    console.log("first");
    return function (a) {
        console.log("second");
        return a;
    };
})()("saikumar");
console.log((function () { return "hi saku"; })());
var out = function (a) { return function (x, y) { return x + y + a; }; };
console.log(out(10)(20, 30));
var out1 = function (a) {
    return function (x, y) {
        return a + x + y;
    };
};
console.log("Hi " + out1(1)(2, 3));
var arr123 = [45, 40, 32, 12, 67, 88, 45, 24, 19];
console.log(arr123.filter(function (e) { return e % 4 == 0; }));
