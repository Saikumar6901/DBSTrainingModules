interface iDidsomething{
    worked():string;
}
export class Greetings{
    public strProp:string;
    private numProp:number;
    protected safeProp:any="some safe locker here";
    anonProp:any;
    static aStaticProp:string="I'm static";
    static greetingsmsg:string="welcome to dbs";
}
class SpecialGreetings extends Greetings implements iDidsomething{
    constructor(){
        super();
    }
    public getSafeProp(){
        return this.safeProp;
    }
    worked():string{
        return "i'm in SpecialGreetings worked() method";
    }
}
var greet=new SpecialGreetings();
console.log(greet.getSafeProp());
console.log(Greetings.aStaticProp);
console.log(SpecialGreetings.aStaticProp);
console.log(greet.worked());
