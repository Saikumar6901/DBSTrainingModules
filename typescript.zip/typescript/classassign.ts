import {Greetings} from './classes';
import {iOperations} from './iOperations';

class Person implements iOperations{
    protected bankBalance:number=12345678;
    static greetingMsg:string="I'm Person class";
    private bestfriend:string="abhibhar";
    name:string;
    age:number;
    constructor(name:string,age:number){
        this.name=name;
        this.age=age;
    }
    getName(): string {
        console.log("person name");
        return this.name;
    }   
    getAge(): number {
        console.log("person age");
        return this.age;
    }
    protected sendGreetings(){
        console.log("in person");
        return "welcome "+this.name;
    }
}
class Employee extends Person{
    constructor(name:string,age:number){
        super(name,age);
    }
    getName(): string {
        console.log("emp name");
        return this.name;
    }   
    getAge(): number {
        console.log("emp age");
        return this.age;
    }
    getBankbalance():number{
        return this.bankBalance;
    }
    sendChildGreetings():String{
        return this.sendGreetings();
    }
}
var emp:Employee=new Employee("saikumar",21);
// console.log(emp.getName());
// console.log(emp.getAge());
// console.log(emp.getBankbalance());
// console.log(Employee.greetingMsg);
console.log(emp.sendChildGreetings());
console.log(Greetings.greetingsmsg);

// var emp2:Person=new Employee("saikumar",21);
// console.log(emp2.getName());
// console.log(emp2.getAge());

// var emp2:Person=new Person("saikumar",21);
// console.log(emp2.getName());
// console.log(emp2.getAge());

// var emp2:iOperations=new Employee("saikumar",21);
// console.log(emp2.getName());
// console.log(emp2.getAge());