package com.calculator;

public interface Calc {
public void add();
}
