package com.helloworld;

public class Helloconstrc {
String msg;
	public Helloconstrc() {
		// TODO Auto-generated constructor stub
		super();
	}
	public Helloconstrc(String msg) {
		// TODO Auto-generated constructor stub
		this.msg=msg;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void sayHi() {
		System.out.println(msg);
	}

}
