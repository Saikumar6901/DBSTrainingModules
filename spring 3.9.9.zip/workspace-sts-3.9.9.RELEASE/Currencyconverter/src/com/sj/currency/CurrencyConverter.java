package com.sj.currency;

public interface CurrencyConverter {
  public double convertCurrency(double amount);
}
