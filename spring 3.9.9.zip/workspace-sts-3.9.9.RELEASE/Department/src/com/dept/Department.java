package com.dept;

public interface Department {
public void deptName();
}
