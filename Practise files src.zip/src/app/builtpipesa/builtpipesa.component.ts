import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-builtpipes',
  templateUrl: './builtpipesa.component.html',
  styleUrls: ['./builtpipesa.component.css']
})
export class BuiltpipesaComponent implements OnInit {
  title:string="training program";
  names:string="";
  jsonobj:any={
    name:"saikumar",
    age:22,
    place:"NLG"
  }
  constructor() { }

  ngOnInit() {
  }

}
