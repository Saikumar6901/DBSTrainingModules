import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuiltpipesaComponent } from './builtpipesa.component';

describe('BuiltpipesaComponent', () => {
  let component: BuiltpipesaComponent;
  let fixture: ComponentFixture<BuiltpipesaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuiltpipesaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuiltpipesaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
