export class Maths {

    Add(x:number, y:number): number{
        return x+y;
    }

}
