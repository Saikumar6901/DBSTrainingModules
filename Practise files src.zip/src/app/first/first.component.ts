import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
  ngOnInit() {
  }
  title:string;
  name:string;
  constructor(){
    this.name="saku";
    this.title="first application";
  }
  getName():string{
    return "my name is "+this.name;
  }
  onClick(name1:string,title1:string){
    debugger
    this.name=name1;
    this.title=title1;
  }
}
