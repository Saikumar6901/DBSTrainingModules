import { Component, OnInit } from '@angular/core';
import {Movie} from '../movie';
@Component({
  selector: 'app-moviecomponent',
  templateUrl: './moviecomponent.component.html',
  styleUrls: ['./moviecomponent.component.css']
})
export class MoviecomponentComponent implements OnInit {
  wishlist:string[] = ["Iphone","mac lapy"];
  reviewStatus:boolean=false;
  bookticketstatus:boolean=false;
  addmovie:boolean=false;
   moviename:string="";
    review:string="";
    director:string="";
    releasedate:Date;
    budget:number=0;
    musicdirector:string="";
    currdate:Date = new Date();
    public mobj:Movie;
    moviearr:Movie[]=[];
    showMovies:boolean=false;
  constructor() { 
    this.mobj=new Movie("saaho","Sujeeth",new Date("08-30-2019"),30000000,"Guru");
   
  }
  onClick(){
    debugger
    this.mobj=new Movie(this.moviename,this.director,new Date(this.releasedate),this.budget,this.musicdirector,this.review);
    this.moviearr.push(this.mobj);
  }
  getMovies(){
    this.showMovies=true;
    this.addmovie=false;
  }
  setmovie(){
    this.showMovies=false;
    this.addmovie=true;
  }
  ngOnInit() {
  }
}
