import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-http-promise',
  templateUrl: './http-promise.component.html',
  styleUrls: ['./http-promise.component.css']
})
export class HttpPromiseComponent  {
  data:any=[]
  buttonstatus:boolean=false;
  constructor(public http:HttpClient) { }
  getCall(){
    this.buttonstatus=true;
     this.http.get("http://jsonplaceholder.typicode.com/posts")
     .toPromise()
     .then(
       (data)=>{console.log("in data block");console.log(data); this.data=data;},
       (error)=>{console.log("in error block");console.log(error);}
     )
     .catch((err) => {
       console.log("In catch block");
       console.log(err);
     })
     .finally(()=>{console.log("in finally");});
     ;
  }
  getRegis(){
    this.buttonstatus=true;
     this.http.get("http://localhost:23456/webs/hi")
     .toPromise()
     .then(
       (data)=>{console.log("in data block");console.log(data); },
       (error)=>{console.log("in error block");console.log(error);}
     )
     .catch((err) => {
       console.log("In catch block");
       console.log(err);
     })
     .finally(()=>{console.log("in finally");});
     ;
  }


}
