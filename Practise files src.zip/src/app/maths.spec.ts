import { Maths } from './maths';
import { match } from 'minimatch';

describe('Test Add',()=>{
let obj = new Maths();
  it("True equals True",()=>{
    expect(true).toBe(true);
    expect(true).toBeTruthy();
  });

  it('should create an object', () => {
     expect(obj).toBeTruthy();
  });

  it("Should add 2 numbers",()=>{
    let n1 = 10; let n2 = 20;
    expect(obj.Add(n1,n2)).toEqual(30);
  });

  it("Should subtract 2 num's if one is negative",()=>{
    
    let n1 = 10; let n2 = -20;
    expect(obj.Add(n1,n2)).toEqual(-10);
  });
})
