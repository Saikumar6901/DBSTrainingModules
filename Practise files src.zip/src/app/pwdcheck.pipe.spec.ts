import { PwdcheckPipe } from './pwdcheck.pipe';

describe('PwdcheckPipe', () => {
  it('create an instance', () => {
    const pipe = new PwdcheckPipe();
    expect(pipe).toBeTruthy();
  });
});
