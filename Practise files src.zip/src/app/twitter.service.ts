import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TwitterService {

  constructor() { }
  getTweets(pUser:string): number{
      if(pUser == "sai")
       return 50;
      return 10;
  }
}
