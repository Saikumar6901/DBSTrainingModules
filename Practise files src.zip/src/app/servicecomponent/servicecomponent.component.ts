import { Component, OnInit } from '@angular/core';
import { FacebookService } from '../facebook.service';
import { TwitterService } from '../twitter.service';

@Component({
  selector: 'app-servicecomponent',
  templateUrl: './servicecomponent.component.html',
  styleUrls: ['./servicecomponent.component.css']
})
export class ServicecomponentComponent implements OnInit {
  userPosts=[];
  constructor(public fbservices:FacebookService, public tweetService: TwitterService) {
   }

  ngOnInit() {
  }
  getData(pUser:string){
       this.userPosts= this.fbservices.getAllPosts(pUser);
  }

}
