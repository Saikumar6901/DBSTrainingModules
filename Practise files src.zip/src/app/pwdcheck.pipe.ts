import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pwdcheck'
})
export class PwdcheckPipe implements PipeTransform {

  transform(value1: any, ...args: any[]): any {
    let resetPwd:string=<string>args[0];
    if(value1 === resetPwd){
      return "success";
    }
    return "Password should be same as above";
  }
}
