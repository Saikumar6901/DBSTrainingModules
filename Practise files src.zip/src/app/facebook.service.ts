import { Injectable } from '@angular/core';
import { TouchSequence } from 'selenium-webdriver';
import { ElementSchemaRegistry } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class FacebookService {
   //private _fbPostsObj:FbPosts=new FbPosts();
  constructor() { }
  getAllPosts(pUser:string): FbPosts[]{
     var allPosts:FbPosts[] = new FbPosts().getAllPosts();
     var _userPosts:FbPosts[]=[];
     allPosts.forEach(element => {
       if(element.uname == pUser){
         _userPosts.push(element);
       }
     });
     return _userPosts;
  }
  getAdDuration(pPostTitle:string,){}
}
class FbPosts{
  uname:string;
  postTitle:string;
  postDescription:string;
  private _posts:FbPosts[]=[];

  getAllPosts():FbPosts[]{
    var post=new FbPosts();
    post.uname="sai";
      post.postTitle="first post";
     post.postDescription="jwevgfhwefihewfoh";
     this._posts.push(post);
     var post2=new FbPosts();
     post2.uname="subbu";
       post2.postTitle="first lec";
      post2.postDescription="kmit";
      this._posts.push(post2);
      return this._posts;
  }
}
class FbAds{
  postTitle:string;
  adCost:string;
  adDuration:number;
}