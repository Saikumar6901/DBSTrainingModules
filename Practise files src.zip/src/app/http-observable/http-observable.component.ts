import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-http-observable',
  templateUrl: './http-observable.component.html',
  styleUrls: ['./http-observable.component.css']
})
export class HttpObservableComponent implements OnInit {

  public subscribedData:Subscription;
  constructor(public http:HttpClient) { }

  ngOnInit() {
  }
  getCall(){
    console.log("hi");
     this.subscribedData=this.http.get("http://localhost:23456/webs/registrations")
                          .subscribe((data) => console.log(data));
     console.log("bye");
  }
  getUnsubscribe(){
    this.subscribedData.unsubscribe();
  }
}
