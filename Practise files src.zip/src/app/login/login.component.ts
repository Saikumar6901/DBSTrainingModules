import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
result:string="failure";
  constructor() { }

  ngOnInit() {
  }
  uname:string;
  pwd:string;
  bool:boolean=false;
  onClick(status:any,imgstatus:any){
    debugger
    if(this.uname=="saikumar" && this.pwd=="sai"){
      this.result="Success;";
      status.style="color:green";
      imgstatus.src='/assets/images.jpg';
    }
    else{
     this.result="Failure;";
     status.style="color:red";
     this.bool=true;
     imgstatus.src='';
    }
     console.log(status);
  }
}
