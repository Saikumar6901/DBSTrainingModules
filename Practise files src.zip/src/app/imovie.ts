export interface IMovie {
    getMovieName();
    getReview();
    getDirector();
    getReleaseDate();
    getTicketPrice();
    getBudget();
}
