import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { RoutingModule } from './routing.module';

import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { IfComponent } from './if/if.component';
import { ForComponent } from './for/for.component';
import { MoviecomponentComponent } from './moviecomponent/moviecomponent.component';
import { SwitchComponent } from './switch/switch.component';
import { BuiltpipesaComponent } from './builtpipesa/builtpipesa.component';
import { StrreversePipe } from './strreverse.pipe';
import { SpeakComponent } from './speak/speak.component';
import { ListenComponent } from './listen/listen.component';
import { PwdcheckPipe } from './pwdcheck.pipe';
import { ServicecomponentComponent } from './servicecomponent/servicecomponent.component';
import { HttpPromiseComponent } from './http-promise/http-promise.component';
import { HttpObservableComponent } from './http-observable/http-observable.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    LoginComponent,
    RegistrationComponent,
    IfComponent,
    ForComponent,
    MoviecomponentComponent,
    SwitchComponent,
    BuiltpipesaComponent,
    StrreversePipe,
    SpeakComponent,
    ListenComponent,
    PwdcheckPipe,
    ServicecomponentComponent,
    HttpPromiseComponent,
    HttpObservableComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
