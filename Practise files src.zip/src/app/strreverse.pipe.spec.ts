import { StrreversePipe } from './strreverse.pipe';

describe('StrreversePipe', () => {
  it('create an instance', () => {
    const pipe = new StrreversePipe();
    expect(pipe).toBeTruthy();
  });
});
