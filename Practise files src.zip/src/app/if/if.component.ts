import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-if',
  templateUrl: './if.component.html',
  styleUrls: ['./if.component.css']
})
export class IfComponent implements OnInit {
  isLoggedIn:boolean=false;
  constructor() { }

  ngOnInit() {
  }
  onClick(){
    this.isLoggedIn = !this.isLoggedIn;
  }

}
