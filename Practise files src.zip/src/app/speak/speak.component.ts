import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-speak',
  templateUrl: './speak.component.html',
  styleUrls: ['./speak.component.css']
})
export class SpeakComponent implements OnInit {
  result:string="";
  @Input() custId:number=123;
  @Output() speak=new EventEmitter();
  @Input() sampleng:string="hgvjh";
  constructor() { }
  ngOnInit() {
  }

}
