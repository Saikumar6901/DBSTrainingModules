import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for',
  templateUrl: './for.component.html',
  styleUrls: ['./for.component.css']
})
export class ForComponent implements OnInit {
  players:any=[];
  cPlayers:Player[]=[];
  constructor() { 
    var p1=new Player();
    p1.id=1001;
    p1.name="kohli";
    this.cPlayers.push(p1);
  }
  ngOnInit() {
    this.players.push({id:100, name:'MS Dhoni'});
    this.players.push({id:101, name:'sachin'});
    this.players.push({id:102, name:'rohit'});
  }

}
class Player{
  public id:number;
  public name:string;
}
