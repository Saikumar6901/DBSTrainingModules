import { Component, OnInit, Input, Output } from '@angular/core';

@Component({
  selector: 'app-listen',
  templateUrl: './listen.component.html',
  styleUrls: ['./listen.component.css']
})
export class ListenComponent implements OnInit {
  customerid:number;
  @Input() @Output() prop:string;
  constructor() { }
 
  ngOnInit() {
  }
  onSpeak(box:any){
    this.customerid = box.value;
  }

}
