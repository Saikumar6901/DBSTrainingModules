import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TimeoutService{
  timer:number=3*60;
    constructor() { 
      sessionStorage.setItem("logged","true");
      
      this.createEvent();
    }
  
    createEvent(){
      if(sessionStorage.getItem("logged")== "true"){
      window.setInterval(this.eventhandler,this.timer*1000);
      window.addEventListener("mousemove",this.handler1);
      window.addEventListener("click",this.handler1);
      window.addEventListener("keyup",this.handler1);
      }
    }
  
    public handler1(){
     
     this.timer=180;
      
      
   }
  
    public eventhandler(){
      if(this.timer>0)
     { this.timer-=1;
     }
      if(this.timer==0){
      window.alert("Session timed out");
      sessionStorage.setItem("logged","false");
      window.location.href="app";
      }
    }
  
  
  }
