import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TimeoutService } from '../timeout.service';

@Component({
  selector: 'app-bankdashboard',
  templateUrl: './bankdashboard.component.html',
  styleUrls: ['./bankdashboard.component.css']
})
export class BankdashboardComponent implements OnInit {
sub:any;
timstamp:string="";
  constructor(public route:ActivatedRoute,private router:Router,private timeout:TimeoutService) { }
  tempValue: string = 'home';//default value
  ngOnInit() {
    if(sessionStorage.getItem("admin") == null || sessionStorage.getItem("admin") == "false"){
      this.router.navigate(["app"]);
    }
    // this.sub = this.route.params
    // .subscribe( params => {
    //   debugger
    //   this.timstamp = params['str'];
    //   });
    //   console.log(this.timstamp);
  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['app']);
  }

  onButtonClick(tempValue:string) {
    
      this.tempValue = tempValue;
  }

}

