import { Component, OnInit, Input } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-passwordset',
  templateUrl: './passwordset.component.html',
  styleUrls: ['./passwordset.component.css']
})
export class PasswordsetComponent implements OnInit {
   custid: String="";
   sub:any;
  constructor(public route:ActivatedRoute, public http:HttpClient,public router:Router) { }

  ngOnInit() {
    this.sub = this.route.params
    .subscribe( params => {
      this.custid = params['custid'];
      });
    }
onSubmit(form:NgForm){
  this.http.post("http://localhost:8079/details/login",
  {
    "login_id": this.custid,
    "pwd": form.value.pwd,
    "last_login_time": "1998-09-09"
  })
  .toPromise()
  .then(
      data => {
          if(data["response"]=="Success"){
            this.router.navigate(['/customerlogin']);
          }
          else{
            this.router.navigate(['/error']);
          }
      },
      error => {
      }
  ); 
}
}
