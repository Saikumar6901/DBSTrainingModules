import { Component, OnInit, ViewChild} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';



@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {

  
  login_id:string='';
  pwd:string='';

  constructor(public http:HttpClient,public router:Router) { }

  ngOnInit() {
  }

 public popup:boolean=false;

  getCalled()
  {
    this.popup=false;
    this.http.get(`http://localhost:8079/rest/customer/${this.login_id}/${this.pwd}`)
    .toPromise()
      .then(
            (data)=>{     
               if(data['response']=='Success'){
                sessionStorage.setItem("otp","true");
                sessionStorage.setItem("logid",this.login_id);
                
                this.router.navigate(['/otp']);
              
         }

         if(data['response']=='Failure'){
            
              this.popup=true;         
         }
              
            },
            (error)=>{}
        )
        .catch((err)=>{
        })
        .finally(()=>{});
    
  }
}


