import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http' ;

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {

    lastTenTransactions:any = [];
    customerDetails:any = [] ;
    toggleTransactions:boolean = false;
    fromAccountNumber:number = 138910000123456;
    ngOnInit(){
      // get customer account id from the customerdetails
      this.http.get("http://localhost:8079/customerAccount/getCustomerAccountDetails/"+this.fromAccountNumber)
      .toPromise()
      .then(
        (data) => {
           this.customerDetails.push(data);
          },
        (error) => {}
      )
      .catch((err) => {
       
      })
      .finally(() => {});
      // get last 10 transactions from the transaction  tables
     

    }
    constructor (public http:HttpClient) {}

    public getTransactions(acc_number:any){
      this.toggleTransactions = !this.toggleTransactions;
      
      this.http.get("http://localhost:8079/transactions/getLastTenTransactions/"+acc_number)
      .toPromise()
      .then(
        (data) => {
          
            this.lastTenTransactions = (data);
          },
        (error) => {}
      )
      .catch((err) => {
       
      })
      .finally(() => {});
    }
}
 