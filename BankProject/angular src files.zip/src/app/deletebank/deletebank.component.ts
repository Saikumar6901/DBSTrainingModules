import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deletebank',
  templateUrl: './deletebank.component.html',
  styleUrls: ['./deletebank.component.css']
})
export class DeletebankComponent implements OnInit {
   data:any;
   buttonstatus:boolean=false;
  constructor(public http:HttpClient,public router:Router) { }

  ngOnInit() {
  }
  onSubmit(form:any){
    this.buttonstatus=true;
         this.http.delete("http://localhost:8079/webs/registrations/"+form.value.accountnumber)
            .toPromise()
            .then(
              (data)=>{
                    if(data["response"]=="Success"){
                      this.router.navigate(['/success']);
                    }
                    else{
                      this.router.navigate(['/error']);
                    }
            },
              (error)=>{}
            )
            .catch((err) => {
            })
            .finally(()=>{});
  }
}
