import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactcomponent',
  templateUrl: './contactcomponent.component.html',
  styleUrls: ['./contactcomponent.component.css']
})
export class ContactcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
