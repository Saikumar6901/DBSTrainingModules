import { Component, OnInit, OnDestroy, ɵConsole } from '@angular/core';
import { HttpClient } from '@angular/common/http' ;
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TransactionServiceService } from '../transaction-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  accNumber:number;
  isPayeeSelected = false;
  selectorReference:string = 'initial';
  sub:any;
  custId:number = Number(sessionStorage.getItem("logid"));
  accountNo: number;
  ifscCode:string;
  amount:number;
  status:string;

  fromAccountNumber:number;
  fromAccountBalance:number;
  constructor( public http:HttpClient, 
                public router: Router, 
                public activatedRouter : ActivatedRoute,
                public transService:TransactionServiceService ) { 
                }

  ngOnInit() {
   
    
    this.accNumber = 138910000123456;
    this.http.get("http://localhost:8079/customerAccount/getCustomerAccountDetails/"+this.accNumber)
    .toPromise()
    .then(
      (data) => {
        this.fromAccountNumber = data['acc_no'];
        this.fromAccountBalance = data['amount'];
        },
      (error) => {}
    )
    .catch((err) => {
    })
    .finally(() => {});
    
  }
  payeeSelected () {
    this.isPayeeSelected = !this.isPayeeSelected;
  }
  onSubmit(form:NgForm){
    let flag = 1;
     if(form.valid == true || form.status == 'VALID'){
       this.accountNo = form.value.accountNo;
       this.amount = form.value.amount;
       this.ifscCode = form.value.ifscCode;
     }
    
     
   
          this.http.post("http://localhost:8079/transactions/addTransaction",
     {
      "fromacc":this.accNumber ,
      "toacc":this.accountNo,
      "amount":this.amount,
     })
     .toPromise()
     .then(
         data => {
             this.status = "POST Request is successful";
         },
         error => {
             this.status = "Error";
            flag = 0;
         }
     );
     
         if(flag == 1){
          this.transService.statusForTransaction = "SUCCESS";
          this.selectorReference = 'SUCCESS';
         }else{
          this.transService.statusForTransaction = "FAILURE";
          this.selectorReference = 'SUCCESS';
         }
    
   }

   public isAccountExists(accNo:any):boolean{
    this.http.get("http://localhost:8079/customerAccount/getAccounts/"+accNo)
    .toPromise()
    .then(
      (data) => {  
          if(data) return true; 
          else return false;
        },
      (error) => {}
    )
    .catch((err) => {
    });
    return false;
   }
   getAccountNo(){
    this.http.get("http://localhost:8079/customerAccount/getCustomerAccountDetails1/"+this.custId)
    .toPromise()
    .then(
      (data) => {
         this.accNumber = data[0]['acc_no'];
        },
      (error) => {}
    )
    .catch((err) => {
    });
    return false;
   }
}
