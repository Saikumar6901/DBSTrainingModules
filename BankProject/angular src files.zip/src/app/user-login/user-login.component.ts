import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
timstamp:string="";
  username:string='';
  password:string='';

  constructor(public route:ActivatedRoute, public http:HttpClient, public router: Router) { }
sub:any;
  ngOnInit() {
  }

getCalled()
  {
    
    this.http.get("http://localhost:8079/rest/user/"+this.username+"/"+this.password)
    .toPromise()
      .then(
        (data)=>{
  
          
          if(data["response"]=="success"){
            sessionStorage.setItem("admin","true");
            this.router.navigate(['/bankdashboard/']);
          }
          else{
            this.router.navigate(['/userlogin']);
          }
        },
            (error)=>{}
        )
        .catch((err)=>{
        })
        .finally(()=>{});
    
  }

}
