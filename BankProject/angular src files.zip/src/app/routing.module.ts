import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule,Routes } from '@angular/router';

import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { PhnUIComponent } from './phn-ui/phn-ui.component';
import { NewUICompComponent } from './new-uicomp/new-uicomp.component';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { PasswordresetComponent } from './passwordreset/passwordreset.component';

import { TransactionComponent } from './transaction/transaction.component';
import { CummunicatorComponent } from './cummunicator/cummunicator.component';
import { FirstComponent } from './first/first.component';
import { PasswordsetComponent } from './passwordset/passwordset.component';
import { CustregistrationComponent } from './custregistration/custregistration.component';
import { BankregisComponent } from './bankregis/bankregis.component';
import { UpdatebankComponent } from './updatebank/updatebank.component';
import { DeletebankComponent } from './deletebank/deletebank.component';
import { ErrorcomponentComponent } from './errorcomponent/errorcomponent.component';
import { SuccesscomponentComponent } from './successcomponent/successcomponent.component';
import { BankdashboardComponent } from './bankdashboard/bankdashboard.component';
import { FaqcomponentComponent } from './faqcomponent/faqcomponent.component';
import { ContactcomponentComponent } from './contactcomponent/contactcomponent.component';




export const router:Routes=[
  {path:"",redirectTo:"app",pathMatch:"full"},
  {path:"app",component:HomepageComponent},
  
  // OTP AUTH
  {path:"otp",component:PhnUIComponent},

  // Bank User Login
  {path:"adminlogin",component:UserLoginComponent},
  
  // Customer login
  {path:"customerlogin",component:CustomerLoginComponent},
   {path:"customerdashboard",component:NewUICompComponent},
  {path:"passwordreset",component:PasswordresetComponent},


  { path : 'addTransaction', component:TransactionComponent},
  { path: 'transferFunds',component:CummunicatorComponent},
  { path: 'commutor',component:CummunicatorComponent},
  { path: 'lastTenTransactions', component:FirstComponent},

  {path:  "bankdashboard", component:BankdashboardComponent},
  
 {path:"passwdreset/:custid",component:PasswordsetComponent},
 {path:"registration",component:CustregistrationComponent},
 {path:"bankregis",component:BankregisComponent},
 {path:"bankupdate",component:UpdatebankComponent},
 {path:"bankdelete",component:DeletebankComponent},
 {path:"error",component:ErrorcomponentComponent},
 {path:"success",component:SuccesscomponentComponent},
 {path:"faq",component:FaqcomponentComponent},
 {path:"contact",component:ContactcomponentComponent},
 {path:"**",component:ErrorcomponentComponent}

];


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(router)  
  ],
  exports:[RouterModule]
})
export class RoutingModule { }
