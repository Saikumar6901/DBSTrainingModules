import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TimeoutService } from '../timeout.service';

@Component({
  selector: 'app-new-uicomp',
  templateUrl: './new-uicomp.component.html',
  styleUrls: ['./new-uicomp.component.css']
})
export class NewUICompComponent implements OnInit {

  toggleButton:string;

  constructor(private router:Router,private timeout:TimeoutService) { }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['app']);
  }

  ngOnInit() {
    if(sessionStorage.getItem("otp") == "true"){
      sessionStorage.removeItem("otp");
    }
    if(sessionStorage.getItem("dashboard") == null || sessionStorage.getItem("dashboard") == "false"){
      this.router.navigate(["app"]);
    }
  }

  onButtonClick(input:string) {
      this.toggleButton = input;
  }

}
