import { Component, OnInit } from '@angular/core';
import * as firebase from 'firebase';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-phn-ui',
  templateUrl: './phn-ui.component.html',
  styleUrls: ['./phn-ui.component.css']
})
export class PhnUIComponent implements OnInit {
  public recaptchaVerifier: firebase.auth.RecaptchaVerifier;
  public sent: boolean;
  public phone_number:string = '7801019735';
  public otp:string= null;
  public confirmobj:any = {};
  public popup:boolean=false;
  public errmsg:string='';
  sub:any;
  constructor(public route:ActivatedRoute,public router:Router) {
    
    const firebaseConfig = {
      apiKey: "AIzaSyBJPImmg65NwSBLAOasTR9aTH8N016Px74",
      authDomain: "onlinebankapp.firebaseapp.com",
      databaseURL: "https://onlinebankapp.firebaseio.com",
      projectId: "onlinebankapp",
      storageBucket: "",
      messagingSenderId: "183806106964",
      appId: "1:183806106964:web:94e9db68d5be0f4d"
    };
    // Initialize Firebase
    if (!firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
    }
   }

   ngOnInit() {
    //  this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container');
    if(sessionStorage.getItem("otp") == null || sessionStorage.getItem("otp") == "false"){
      this.router.navigate(["app"]);
    }
  
  
    this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
    'size': 'invisible',
    'callback': function(response) {
      // reCAPTCHA solved, allow signInWithPhoneNumber.
      
     this.onSubmit();
    }
  });
  this.onSubmit();
}
onSubmit() {
  this.popup=false;
  const appVerifier = this.recaptchaVerifier;
  const phoneNumber = "+91"+this.phone_number;
   firebase.auth().signInWithPhoneNumber(phoneNumber, appVerifier)
   .then((confirmationResult) => {
      this.sent = true;
      this.confirmobj = confirmationResult;
    })
    .catch((err) => {
      this.errmsg="Sms not sent as there are many requests!Try again later";
      this.popup=true;

    });
}
 verifyOTP(){
  this.popup=false;
   if(this.otp!=null){
    this.confirmobj.confirm(this.otp)
    .then((good)=>{
          
     this.router.navigate(['/customerdashboard']);
      sessionStorage.setItem("dashboard","true");

    })
    .catch((bad) => {
      this.errmsg="OTP Invalid! Re-enter OTP";
      this.popup=true;
      //         // code verification was bad.
           });
   }
   else{
    this.errmsg="No verification code entered.";
    this.popup=true;
   }
   
 }
}
