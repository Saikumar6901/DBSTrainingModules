import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-custregistration',
  templateUrl: './custregistration.component.html',
  styleUrls: ['./custregistration.component.css']
})
export class CustregistrationComponent implements OnInit {
  termsStatus:boolean=false;
  accStatus: boolean = false;
  panStatus: boolean = false;
  registerStatus:boolean=true;
  accnumber:number;
  pannumber:string="";
  data:any=[];
  constructor(public http:HttpClient,public router:Router) { 
  }
  ngOnInit() {
  }
  onSubmit(form:NgForm){
    if(form.valid == true){
       this.data= this.http.post("http://localhost:8079/regis/custregis",
        {
            "acc_no": form.value.accountnumber,
            "pan_no": form.value.pan
        })
        .toPromise()
        .then(
            data => {
                if(data["response"] == "Success"){
                    this.router.navigate(['/passwdreset/'+data["custid"]]);
                }
                else{
                  this.router.navigate(['/error']);
                }
            },
            error => {
            }
        ); 
    }
  }
}
