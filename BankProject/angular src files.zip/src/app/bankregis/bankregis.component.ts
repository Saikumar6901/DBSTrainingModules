import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bankregis',
  templateUrl: './bankregis.component.html',
  styleUrls: ['./bankregis.component.css']
})
export class BankregisComponent implements OnInit {
  buttstatus:boolean=false;
  respons:any=[];
  constructor(public http:HttpClient, public router: Router) { }

  ngOnInit() {
  }
 onClick(){
   this.buttstatus=true;
 }
 onSubmit(form: NgForm){
 
   console.log("hi");
   console.log(form);
   this.respons=this.http.post("http://localhost:8079/webs/registrations",
   {
       "pan_no": form.value.panno,
       "firstname": form.value.fname,
       "middlename": form.value.mname,
       "lastname": form.value.lname,
       "phone_no": form.value.phno,
       "email_id": form.value.email,
       "date_of_birth": form.value.dob,
       "address": form.value.address,
       "zipcode": form.value.zipcode,
       "account_type": form.value.acctype,
       "balance": form.value.balance,
       "ifsc_code": form.value.ifsc,
       "account_status": form.value.accstatus    
   })
   .toPromise()
   .then(
       data => {
           if(data["response"]=="Success"){
               this.router.navigate(['/bdashboard']);
           }
           else{
            this.router.navigate(['/error']);
           }
       },
       error => {
         
       }
   ); 
 
 }
}
