import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faqcomponent',
  templateUrl: './faqcomponent.component.html',
  styleUrls: ['./faqcomponent.component.css']
})
export class FaqcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  bool1:boolean;
  bool2:boolean;
  bool3:boolean;
  bool4:boolean;

  call1(){
    this.bool1 = !this.bool1;
  }
  
  
  call2(){
    this.bool2 = !this.bool2;
  }
  
  call3(){
    this.bool3 = !this.bool3;
  }
  
  call4(){
    this.bool4 = !this.bool4;
  }

}