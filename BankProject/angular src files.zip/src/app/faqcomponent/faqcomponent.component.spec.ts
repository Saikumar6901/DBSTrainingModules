import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FaqcomponentComponent } from './faqcomponent.component';

describe('FaqcomponentComponent', () => {
  let component: FaqcomponentComponent;
  let fixture: ComponentFixture<FaqcomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaqcomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaqcomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
