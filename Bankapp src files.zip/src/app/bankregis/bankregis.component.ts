import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-bankregis',
  templateUrl: './bankregis.component.html',
  styleUrls: ['./bankregis.component.css']
})
export class BankregisComponent implements OnInit {
  buttstatus:boolean=false;
  respons:any=[];
  constructor(public http:HttpClient) { }

  ngOnInit() {
  }
 onClick(){
   this.buttstatus=true;
 }
 onSubmit(form: NgForm){
   debugger
   console.log("hi");
   console.log(form);
  //  this.http.get("http://localhost:23456/regis/hi")
  //  .toPromise()
  //  .then(
  //    (data)=>{console.log("in data block");console.log(data); },
  //    (error)=>{console.log("in error block");console.log(error);}
  //  )
  //  .catch((err) => {
  //    console.log("In catch block");
  //    console.log(err);
  //  })
  //  .finally(()=>{console.log("in finally");});
   this.respons=this.http.post("http://localhost:23456/webs/registrations",
   {
      // "account_no": form.value.account,
       "pan_no": form.value.panno,
       "firstname": form.value.fname,
       "middlename": form.value.mname,
       "lastname": form.value.lname,
       "phone_no": form.value.phno,
       "email_id": form.value.email,
       "date_of_birth": form.value.dob,
       "address": form.value.address,
       "zipcode": form.value.zipcode,
       "account_type": form.value.acctype,
       "balance": form.value.balance,
       "ifsc_code": form.value.ifsc,
       "account_status": form.value.accstatus    
   })
   .toPromise()
   .then(
       data => {
           console.log("POST Request is successful ", data);
       },
       error => {
           console.log("Error", error);
       }
   ); 
   console.log(this.respons);
 }
}
