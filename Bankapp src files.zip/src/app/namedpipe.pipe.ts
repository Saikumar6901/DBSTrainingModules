import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'namedpipe'
})
export class NamedpipePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return null;
  }

}
