import { Component, OnInit, Input } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-passwordset',
  templateUrl: './passwordset.component.html',
  styleUrls: ['./passwordset.component.css']
})
export class PasswordsetComponent implements OnInit {
   custid: String="";
   sub:any;
  constructor(public route:ActivatedRoute, public http:HttpClient,public router:Router) { }

  ngOnInit() {
    this.sub = this.route.params
    .subscribe( params => {
      debugger
      this.custid = params['custid'];
      });
      console.log(this.custid);
    }
onSubmit(form:NgForm){
  console.log(form);
  debugger
  console.log("in ts file");
  this.http.post("http://localhost:9009/details/login",
  {
    "login_id": this.custid,
    "pwd": form.value.pwd,
    "last_login_time": "1998-09-09"
  })
  .toPromise()
  .then(
      data => {
        debugger
          console.log("POST Request is successful ", data);
          if(data["response"]=="Success"){

          }
          else{
            this.router.navigate(['/error']);
          }
      },
      error => {
          console.log("Error", error);
      }
  ); 
}
}
