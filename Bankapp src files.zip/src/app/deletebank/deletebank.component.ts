import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deletebank',
  templateUrl: './deletebank.component.html',
  styleUrls: ['./deletebank.component.css']
})
export class DeletebankComponent implements OnInit {
   data:any;
   buttonstatus:boolean=false;
  constructor(public http:HttpClient,public router:Router) { }

  ngOnInit() {
  }
  onSubmit(form:any){
    this.buttonstatus=true;
         this.http.delete("http://localhost:9004/webs/registrations/"+form.value.accountnumber)
            .toPromise()
            .then(
              (data)=>{console.log("in data block");debugger;
                    if(data["response"]=="Success"){
                      this.router.navigate(['/success']);
                    }
                    else{
                      this.router.navigate(['/error']);
                    }
            },
              (error)=>{console.log("in error block");console.log(error);}
            )
            .catch((err) => {
              console.log("In catch block");
              console.log(err);
            })
            .finally(()=>{console.log("in finally");});
  }
}
