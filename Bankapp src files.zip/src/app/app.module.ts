import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { CustregistrationComponent } from './custregistration/custregistration.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';
import { BankregisComponent } from './bankregis/bankregis.component';
import { PasswordsetComponent } from './passwordset/passwordset.component';
import { CheckpasswordPipe } from './checkpassword.pipe';
import { UpdatebankComponent } from './updatebank/updatebank.component';
import { DeletebankComponent } from './deletebank/deletebank.component';
import { RoutingModule } from './routing.module';
import { ErrorcomponentComponent } from './errorcomponent/errorcomponent.component';
import { SuccesscomponentComponent } from './successcomponent/successcomponent.component';
import { PersonalcomponentComponent } from './personalcomponent/personalcomponent.component';
import { NamedpipePipe } from './namedpipe.pipe';

@NgModule({
  declarations: [
    AppComponent,
    CustregistrationComponent,
    UserregistrationComponent,
    BankregisComponent,
    PasswordsetComponent,
    CheckpasswordPipe,
    UpdatebankComponent,
    DeletebankComponent,
    ErrorcomponentComponent,
    SuccesscomponentComponent,
    PersonalcomponentComponent,
    NamedpipePipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
