import { NamedpipePipe } from './namedpipe.pipe';

describe('NamedpipePipe', () => {
  it('create an instance', () => {
    const pipe = new NamedpipePipe();
    expect(pipe).toBeTruthy();
  });
});
