import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-updatebank',
  templateUrl: './updatebank.component.html',
  styleUrls: ['./updatebank.component.css']
})
export class UpdatebankComponent implements OnInit {
  updateDataStatus:boolean=false;
  registration:any;
  data:any="";
  x:string="123";
  buttonStatus:boolean=false;
   original_date:any;
  constructor(public router:Router,public http:HttpClient) { }

  ngOnInit() {
  }
  onSubmit(form:any){
    var acc_no:String = form.value.accountnumber;
    debugger
    this.buttonStatus=true;
        this.http.get("http://localhost:9004/webs/registrations/"+acc_no)
        .toPromise()
        .then(
          (data)=>{console.log("in data block");
          debugger;
          this.data=data;
    var todate=new Date(this.data.date_of_birth).getDate();
    var tomonth=new Date(this.data.date_of_birth).getMonth();
    var toyear=new Date(this.data.date_of_birth).getFullYear();
    //var original_date=tomonth+'/'+todate+'/'+toyear;
    debugger;
  //  console.log(this.data.date_of_birth  | Date: 'dd/MM/yyyy');
    this.original_date=new Date(this.data.date_of_birth).getDate();
   // this.data.date_of_birth=original_date;
    },
          (error)=>{console.log("in error block");console.log(error);}
        )
        .catch((err) => {
          console.log("In catch block");
          console.log(err);
        })
        .finally(()=>{console.log("in finally");});
        console.log(this.data);
  }
  onClick(form:any){
    console.log(form);
    console.log(this.original_date);
  console.log("in onclick()")
  console.log(this.data);
  debugger
    this.http.put("http://localhost:9004/webs/registrations",{
      "account_no":this.data.account_no,
      "pan_no":this.data.pan_no,
      "firstname": this.data.firstname,
      "middlename": this.data.middlename,
      "lastname": this.data.lastname,
      "phone_no": this.data.phone_no,
      "email_id":this.data.email_id,
      "date_of_birth": this.data.date_of_birth,
      "address": this.data.address,
      "zipcode": this.data.zipcode,
      "account_type": this.data.account_type,
      "balance": this.data.balance,
      "customer_id":this.data.customer_id,
      "ifsc_code": this.data.ifsc_code,
      "account_status":this.data.account_status
    })
    .toPromise()
    .then(
      (data)=>{console.log("in data block");console.log(data);
        if(data["response"]=="Success"){
          this.router.navigate(['/success']);
        }
        else{
          this.router.navigate(['/error']);
        }
    },
      (error)=>{console.log("in error block");console.log(error);}
    )
    .catch((err) => {
      console.log("In catch block");
      console.log(err);
    })
    .finally(()=>{console.log("in finally");});
  }

}
