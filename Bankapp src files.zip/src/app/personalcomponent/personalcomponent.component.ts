import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-personalcomponent',
  templateUrl: './personalcomponent.component.html',
  styleUrls: ['./personalcomponent.component.css']
})
export class PersonalcomponentComponent implements OnInit {
custid:number;
sub:any;
data:any;
  constructor(public route:ActivatedRoute, public http:HttpClient,public router:Router) { }
  ngOnInit() {
    this.sub = this.route.params
    .subscribe( params => {
      debugger
      this.custid = params['custid'];
      });
      console.log(this.custid);
    }
  onSubmit(){
  this.http.get("http://localhost:9004/regis/custregis/"+this.custid,
  {})
  .toPromise()
  .then(
      data => {
          console.log("POST Request is successful ", data);
          this.data=data;
          // if(data["response"] == "Success"){
          //   //call dashboard
          //     this.router.navigate(['/passwdreset/'+data["custid"]]);
          // }
          // else{
          //   this.router.navigate(['/error']);
          // }
      },
      error => {
          console.log("Error", error);
      }
  ); 

    }
}
