import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalcomponentComponent } from './personalcomponent.component';

describe('PersonalcomponentComponent', () => {
  let component: PersonalcomponentComponent;
  let fixture: ComponentFixture<PersonalcomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalcomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalcomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
