import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-successcomponent',
  templateUrl: './successcomponent.component.html',
  styleUrls: ['./successcomponent.component.css']
})
export class SuccesscomponentComponent implements OnInit {

  constructor(public router: Router) { }

  ngOnInit() {
  }

  onSubmit(){
    this.router.navigate(['/bankregis']);
 }
}
